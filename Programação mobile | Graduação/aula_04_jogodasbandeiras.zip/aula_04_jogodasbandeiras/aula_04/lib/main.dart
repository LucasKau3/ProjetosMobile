import 'package:aula_04/flag.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final Flags flags = Flags();
  var lifes = 3;

  Widget _popUp(String output) {
    Widget alertPopUp = AlertDialog(
      title: Text(output),
      content: const Text("Deseja jogar novamente?\n(Nova rodada)"),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.pop(context, 'Não'),
          child: const Text('Não'),
        ),
        TextButton(
          onPressed: () {
            Navigator.pop(context, 'Sim');
            setState(() {
              if (output == "Errou") {
                lifes--;
              }
              if (output == "Acertou" || lifes <= 0) {
                flags.resetGame();
                lifes = 3;
              }
            });
          },
          child: const Text('Sim'),
        ),
      ],
    );
    if (lifes > 0) {
      if (output == "Errou") {
        lifes--;
        alertPopUp = AlertDialog(
          title: Text(output),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text('Você tem mais $lifes tentativas'),
                const Text('Deseja jogar novamente?'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.pop(context, 'Não');
                setState(() {});
              },
              child: const Text('Não'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context, 'Sim');
                setState(() {});
              },
              child: const Text('Sim'),
            ),
          ],
        );
      }
      if (output == "Acertou") {
        alertPopUp = AlertDialog(
          title: Text(output),
          content: const Text("Deseja jogar novamente?\n(Nova rodada)"),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.pop(context, 'Não');
                setState(() {});
              },
              child: const Text('Não'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context, 'Sim');
                setState(() {
                  if (output == "Errou") {
                    lifes--;
                  }
                  if (output == "Acertou" || lifes <= 0) {
                    flags.resetGame();
                    lifes = 3;
                  }
                });
              },
              child: const Text('Sim'),
            ),
          ],
        );
      }
    }
    if (lifes == 0) {
      alertPopUp = AlertDialog(
        title: const Text("Acabou as tentivas"),
        content: SingleChildScrollView(
          child: ListBody(
            children: <Widget>[
              Text('Tentivas $lifes'),
              const Text('Deseja jogar novamente?\n(nova rodada)'),
            ],
          ),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () {
              Navigator.pop(context, 'Não');
              setState(() {});
            },
            child: const Text('Não'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context, 'Sim');
              setState(() {
                flags.resetGame();
                lifes = 3;
              });
            },
            child: const Text('Sim'),
          ),
        ],
      );
    }
    return alertPopUp;
  }

  List<Widget> _buildGridTileList() {
    List<Widget> children = [];
    var deck = flags.deck;

    for (var i = 0; i < deck.length; i++) {
      //children.add(Image(image: AssetImage('assets/South_America/${deck[i]}')));

      children.add(Container(
          padding: const EdgeInsets.all(8.0),
          margin: const EdgeInsets.all(8.0),
          color: Colors.blue,
          child: GestureDetector(
              onTap: () {
                String output = flags.checkAnswer(i) ? "Acertou" : "Errou";
                showDialog(
                  context: context,
                  builder: (context) {
                    return _popUp(output);
                  },
                );
              },
              child: Image(
                image: AssetImage('assets/South_America/${deck[i]}'),
              ))));
    }
    return children;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          children: [
            Text("Qual a bandeira do ${flags.answer}?"),
            Text("Tentativas $lifes"),
            Expanded(
                child: GridView.count(
              crossAxisCount: 3,
              children: _buildGridTileList(),
            ))
          ],
        ),
      ),
    );
  }
}
