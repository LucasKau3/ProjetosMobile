class Aluno {
  String nome;
  DateTime dataNascimento;
  int ra;
  String sexo;

  Aluno(
      {required this.nome,
      required this.dataNascimento,
      required this.ra,
      required this.sexo}) {}
}
