import 'dart:math';

class Flags {
  final Random _random = Random();
  int _currentCountry = 0;
  final _flags = [
    "South_America-Argentina.png",
    "South_America-Bolivia.png",
    "South_America-Brazil.png",
    "South_America-Chile.png",
    "South_America-Colombia.png",
    "South_America-Ecuador.png",
    "South_America-Falkland_Islands.png",
    "South_America-French_Polynesia.png",
    "South_America-Guyana.png",
    "South_America-Netherlands_Antilles.png",
    "South_America-Paraguay.png",
    "South_America-Peru.png",
    "South_America-Suriname.png",
    "South_America-Trinidad_and_Tobago.png",
    "South_America-Uruguay.png",
    "South_America-Venezuela.png"
  ];

  Flags() {
    resetGame();
  }

  resetGame() {
    _flags.shuffle();
    _currentCountry = _random.nextInt(6);
  }

  get deck {
    return [_flags[0], _flags[1], _flags[2], _flags[3], _flags[4], _flags[5]];
  }

  get answer {
    return _flags[_currentCountry].split('-').last.split('.').first;
  }

  checkAnswer(int answer) {
    var correct = false;
    if (answer == _currentCountry) {
      correct = true;
    }
    return correct;
  }
}
