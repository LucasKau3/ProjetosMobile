import 'package:flutter/material.dart';

import '../model/aluno.dart';

class AlunoCadastroScreen extends StatefulWidget {
  const AlunoCadastroScreen({super.key, required String title});

  @override
  State<AlunoCadastroScreen> createState() => _AlunoCadastroScreenState();
}

class _AlunoCadastroScreenState extends State<AlunoCadastroScreen> {
  List<Aluno> _listaAlunos = [];
  String? _nome, _sexo;
  DateTime? _dataNascimento;
  int? _ra;

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final List<DropdownMenuItem<String>> _sexoOptions = [
    DropdownMenuItem(value: "Masculino", child: Text("Masculino")),
    DropdownMenuItem(value: "Feminino", child: Text("Feminino")),
    DropdownMenuItem(value: "Outros", child: Text("Outros")),
  ];

  _insertInToListView() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      Aluno aluno = Aluno(
          nome: _nome!,
          dataNascimento: _dataNascimento!,
          ra: _ra!,
          sexo: _sexo!);
      setState(() {
        _listaAlunos.add(aluno);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
            child: ListView.builder(
                itemCount: _listaAlunos.length,
                itemBuilder: (context, index) {
                  //_listaAlunos[index];
                  return ListTile(
                    title: Text(_listaAlunos[index].nome),
                    subtitle: Text(
                      (_listaAlunos[index].ra).toString(),
                    ),
                  );
                })),
        Form(
          key: _formKey,
          child: Column(children: [
            TextFormField(
              onSaved: (newValue) {
                _nome = newValue;
              },
              decoration: const InputDecoration(
                labelText: "Nome",
              ),
            ),
            TextFormField(
              keyboardType: TextInputType.number,
              onSaved: (newValue) {
                _ra = int.parse(newValue!);
              },
              decoration: const InputDecoration(
                labelText: "RA",
              ),
            ),
            TextFormField(
              decoration: InputDecoration(
                  labelText: _dataNascimento != null
                      ? _dataNascimento.toString()
                      : 'Data de Nascimento'),
              readOnly: true, // Impede a edição direta e a abertura do teclado
              onTap: () async {
                // Fecha o teclado virtual, se aberto
                FocusScope.of(context).requestFocus(new FocusNode());
                // Chama o DatePickerDialog
                final DateTime? pickedDate = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime(1900),
                  lastDate: DateTime.now(),
                );
                // Se uma data foi escolhida, atualiza o estado
                if (pickedDate != null) {
                  setState(() {
                    _dataNascimento = pickedDate;
                  });
                }
              },
              validator: (value) {
                if (_dataNascimento == null) {
                  return 'Por favor, selecione uma data';
                }
                return null;
              },
            ),
            DropdownButtonFormField<String>(
              value: _sexo,
              hint: Text("Selecione o sexo"),
              items: _sexoOptions,
              onChanged: (value) => setState(() => _sexo = value!),
              onSaved: (value) => _sexo = value!,
              validator: (value) => value == null ? 'Campo obrigatório' : null,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: ElevatedButton(
                onPressed: () {
                  _insertInToListView();
                },
                child: const Text('Enviar'),
              ),
            ),
          ]),
        ),
      ],
    );
  }
}
