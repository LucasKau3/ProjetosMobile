import 'package:aula_05_sala/bloc/auth_bloc.dart';
import 'package:aula_05_sala/bloc/profile_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class BlocIntroScreen extends StatelessWidget {
  const BlocIntroScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthBloc, AuthStatus>(
      builder: (context, authState) {
        if (authState == AuthStatus.unauthenticated) {
          return authenticatedLayout(context);
        } else {
          return unauthenticatedLayout(context);
        }
      },
    );
  }

  Widget unauthenticatedLayout(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 20),
          ),
          onPressed: () =>
              BlocProvider.of<AuthBloc>(context).add(ToggleAuthEvent()),
          child: const Text('Autenticar'),
        ),
        Text('Por favor, faça a autenticação antes de prosseguir'),
      ],
    );
  }

  Widget authenticatedLayout(BuildContext context) {
    return Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          BlocBuilder<ProfileBloc, ProfileState>(
              builder: (context, profileState) {
            return Column(children: <Widget>[
              ListTile(
                title: const Text('Administrador'),
                leading: Radio<ProfileState>(
                  value: ProfileState.admin,
                  groupValue: profileState,
                  onChanged: (ProfileState? value) {
                    BlocProvider.of<ProfileBloc>(context)
                        .add(SetAdminProfileEvent());
                  },
                ),
              ),
              ListTile(
                title: const Text('User'),
                leading: Radio<ProfileState>(
                  value: ProfileState.user,
                  groupValue: profileState,
                  onChanged: (ProfileState? value) {
                    BlocProvider.of<ProfileBloc>(context)
                        .add(SetAdminProfileEvent());
                  },
                ),
              ),
              ListTile(
                title: const Text('Guest'),
                leading: Radio<ProfileState>(
                  value: ProfileState.guest,
                  groupValue: profileState,
                  onChanged: (ProfileState? value) {
                    BlocProvider.of<ProfileBloc>(context)
                        .add(SetAdminProfileEvent());
                  },
                ),
              ),profileContent(profileState, context)
            ]);
          })
        ]);
  }
}

Widget profileContent(ProfileState profileState, BuildContext context) {
  switch (profileState) {
    case ProfileState.admin:
      return adminLayout(context);
    case ProfileState.user:
      return userLayout(context);
    case ProfileState.guest:
      return guestLayout();
    default:
      return Container(); // Fallback para um estado indefinido
  }
}

Widget adminLayout(BuildContext context) {
  return Center(
    child: ElevatedButton(
      onPressed: () {
        showDialog(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: const Text('Admin'),
              content: const Text('Parabéns por gerenciar o sistema!'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('OK'),
                ),
              ],
            );
          },
        );
      },
      child: const Text('Clique para gerenciar o sistema'),
    ),
  );
}

Widget userLayout(BuildContext context) {
  TextEditingController controller = TextEditingController();
  return Center(
    child: TextField(
      controller: controller,
      decoration: const InputDecoration(
        labelText: 'Digite algo...',
        border: OutlineInputBorder(),
      ),
      onSubmitted: (value) {
        showDialog(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: const Text('Usuário'),
              content: Text('Parabéns por usar o sistema: $value'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('OK'),
                ),
              ],
            );
          },
        );
      },
    ),
  );
}

Widget guestLayout() {
  return Container(
    color: Colors.blue,
    width: double.infinity,
    height: 200,
    child: const Center(
      child: Text('Como visitante, só pode olhar para este fundo azul'),
    ),
  );
}
