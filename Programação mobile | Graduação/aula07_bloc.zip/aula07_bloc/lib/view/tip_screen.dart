import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../model/tip.dart';

class TipScreen extends StatefulWidget {
  const TipScreen({super.key, required this.title});

  final String title;

  @override
  State<TipScreen> createState() => _TipScreenState();
}

class _TipScreenState extends State<TipScreen> {
  Tip tip = Tip();

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        TextFormField(
          initialValue: tip.amount,
          keyboardType: TextInputType.number,
          onChanged: (value) {
            setState(() {
              tip.amount = value;
            });
          },
          decoration: const InputDecoration(labelText: 'Valor Total'),
          inputFormatters: [
            FilteringTextInputFormatter.allow(RegExp(r'^\d*\d*$'))
          ],
        ),
        InputDecorator(
            decoration: const InputDecoration(labelText: 'Gorjeta Customizada'),
            child: Slider(
              min: 1,
              max: 100,
              value: double.parse(tip.customTip),
              onChanged: (double value) {
                setState(() {
                  tip.customTip = value.toString();
                });
              },
            )),
        /*Table(
              border: TableBorder.all(),
                children: [
                  TableRow(
                    children: [
                      WideWidget(),
                      Medi
                    ]
              )
            ],),*/
        Text(
            'Valor da gorjeta(10%) sobre valor da conta: ${tip.defaulTippedAmount}'),
        Text(
            'Valor da gorjeta(personalizada) sobre valor da conta: ${tip.customTippedAmount}'),
        Text(
            'Valor total com 10% de gorgeja:${tip.amountPlusDefaultTippedAmount}'),
        Text(
            'Valor total com gorjeta customizada: ${tip.amountPlusCustomTippedAmount}'),
        Text('Valor padrão da gorjeta:${tip.defaultTip}%'),
        Text('Valor da gorjeta customizada:${tip.customTip}%')
      ],
    );
  }
}
