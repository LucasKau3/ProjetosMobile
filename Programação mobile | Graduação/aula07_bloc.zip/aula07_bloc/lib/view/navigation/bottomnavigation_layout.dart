import 'package:flutter/material.dart';

import '../flag_screen.dart';
import '../formulario.dart';
import '../tip_screen.dart';

class BottomNavigationlayout extends StatefulWidget {
  const BottomNavigationlayout({super.key});

  @override
  State<BottomNavigationlayout> createState() => _BottomNavigationlayoutState();
}

class _BottomNavigationlayoutState extends State<BottomNavigationlayout> {
  int _currentScreen = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Layout BottomBar")),
      body: IndexedStack(
        index: _currentScreen,
        children: [
          FlagScreen(title: "FlagScreen"),
          TipScreen(title: "TipScreen"),
          Formulario(
            title: "FormScreen",
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.abc), label: "Primeira"),
          BottomNavigationBarItem(icon: Icon(Icons.abc), label: "Segunda"),
          BottomNavigationBarItem(icon: Icon(Icons.abc), label: "Terceira"),
        ],
        onTap: (value) {
          setState(() {
            _currentScreen = value;
          });
        },
        currentIndex: _currentScreen,
        fixedColor: Colors.red,
      ),
    );
  }
}
