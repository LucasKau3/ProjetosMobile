import 'package:aula_05_sala/view/aluno_screen.dart';
import 'package:aula_05_sala/view/bloc_intro_screen.dart';
import 'package:flutter/material.dart';

import '../flag_screen.dart';
import '../formulario.dart';
import '../tip_screen.dart';

class DrawerLayout extends StatefulWidget {
  const DrawerLayout({super.key});

  @override
  State<DrawerLayout> createState() => _DrawerLayoutState();
}

class _DrawerLayoutState extends State<DrawerLayout> {
  int _currentScreen = 0;

  changeScreen(int value) {
    setState(() {
      _currentScreen = value;
      Navigator.pop(context);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              child: Text("Menu telas"),
              decoration: BoxDecoration(color: Colors.blue),
            ),
            ListTile(
              title: Text("Bandeiras"),
              tileColor: Colors.white,
              onTap: () {
                changeScreen(0);
              },
            ),
            ListTile(
              title: Text("Calculo de gorjeta"),
              tileColor: Colors.white,
              onTap: () {
                changeScreen(1);
              },
            ),
            ListTile(
              title: Text("Formulario"),
              tileColor: Colors.white,
              onTap: () {
                changeScreen(2);
              },
            ),
            ListTile(
              title: Text("Formulario aluno"),
              tileColor: Colors.white,
              onTap: () {
                changeScreen(3);
              },
            ),
            ListTile(
              title: Text("Autenticação"),
              tileColor: Colors.white,
              onTap: () {
                changeScreen(4);
              },
            ),
          ],
        ),
      ),
      appBar: AppBar(
        title: Text("Layout Drawer"),
      ),
      body: IndexedStack(
        index: _currentScreen,
        children: [
          FlagScreen(title: "FlagScreen"),
          TipScreen(title: "TipScreen"),
          Formulario(
            title: "FormScreen",
          ),
          AlunoCadastroScreen(
            title: "FormScreenAluno",
          ),
          BlocIntroScreen()
        ],
      ),
    );
  }
}
