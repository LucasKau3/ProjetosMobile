import 'dart:ui';

import 'package:aula_05_sala/view/nav.dart';
import 'package:flutter/material.dart';

import '../flag_screen.dart';
import '../formulario.dart';
import '../tip_screen.dart';

class CustomLayout extends StatefulWidget {
  const CustomLayout({super.key, required this.title});

  final String title;

  @override
  State<CustomLayout> createState() => _CustomLayoutState();
}

class _CustomLayoutState extends State<CustomLayout> {
  PageController _pageViewController = PageController(initialPage: 0);

  List<Widget> children = [
    TipScreen(title: "Garçom"),
    FlagScreen(title: "Bandeira"),
    Formulario(title: "Fomulario"),
    Container(
      color: Colors.blue,
    ),
    Container(
      color: Colors.red,
    ),
    Container(
      color: Colors.green,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TopNavigationBar(
                title: "Navega",
                rotulos: ['A', 'B', 'C', 'D', 'E'],
                onTap: (index, rotulo) {
                  _pageViewController.jumpToPage(index);
                }),
            Expanded(
                child: ScrollConfiguration(
                    behavior: ScrollConfiguration.of(context).copyWith(
                      dragDevices: {
                        PointerDeviceKind.touch,
                        PointerDeviceKind.mouse,
                      },
                    ),
                    child: PageView(
                      controller: _pageViewController,
                      children: children,
                    ))),
          ],
        ),
      ),
    );
  }
}
