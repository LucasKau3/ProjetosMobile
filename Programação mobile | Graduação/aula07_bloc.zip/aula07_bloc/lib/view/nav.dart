import 'package:flutter/material.dart';

class TopNavigationBar extends StatefulWidget {
  const TopNavigationBar(
      {super.key,
      required this.title,
      required this.rotulos,
      required this.onTap});

  final String title;
  final List rotulos;
  final Function onTap;

  @override
  State<TopNavigationBar> createState() => _TopNavigationBarState();
}

class _TopNavigationBarState extends State<TopNavigationBar> {
  List<Widget> getChildren() {
    List<Widget> children = [];

    widget.rotulos.asMap().forEach((index, thing) {
      children.add(
        TextButton(
          onPressed: () {
            widget.onTap(index, thing);
          },
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 4.0),
            height: 50,
            decoration:
                BoxDecoration(shape: BoxShape.circle, color: Colors.blue),
            child: Center(
              child: Text(
                thing.toString(),
                style:
                    TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ),
      );
    });

    return children;
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: getChildren(),
    );
  }
}
