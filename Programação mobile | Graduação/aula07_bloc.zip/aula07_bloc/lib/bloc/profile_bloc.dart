import 'package:flutter_bloc/flutter_bloc.dart';

class ProfileBloc extends Bloc<ProfileEvent, ProfileState> {
  ProfileBloc() : super(ProfileState.guest) {
    on<SetAdminProfileEvent>((event, emit) {
      emit(ProfileState.admin);
    });
    on<SetUserProfileEvent>((event, emit) {
      emit(ProfileState.user);
    });
    on<SetGuestProfileEvent>((event, emit) {
      emit(ProfileState.guest);
    });
  }
}

abstract class ProfileEvent {}

class SetAdminProfileEvent extends ProfileEvent {}

class SetUserProfileEvent extends ProfileEvent {}

class SetGuestProfileEvent extends ProfileEvent {}

enum ProfileState {
  admin,
  user,
  guest,
}
