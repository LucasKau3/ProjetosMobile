package com.example.aula07_bloc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
