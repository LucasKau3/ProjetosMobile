package com.example.aula2_si700

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
