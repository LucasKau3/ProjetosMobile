import 'package:aula_05_dados_user/view/flag_screen.dart';
import 'package:aula_05_dados_user/view/nav.dart';
import 'package:aula_05_dados_user/view/tip_screen.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  static const String _title = 'Flutter Stateful Clicker Counter';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      theme: ThemeData(
        // useMaterial3: false,
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;
  PageController _pageController = PageController(initialPage: 0);
  List<Widget> children = [
    TipScreen(title: "Gorjeta"),
    FlagScreen(title: "Bandeira"),
    Container(color: Colors.blue),
    Container(color: Colors.red),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter Demo Click Counter'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TopNavigationBar(
                title: "Aula 05",
                rotulos: ["Página I", "Página II", "Página III", "Página IV"],
                onTap: (index, rotulos) {
                  _pageController.jumpToPage(index);
                }),
            Expanded(
                child: ScrollConfiguration(
                    behavior: ScrollConfiguration.of(context).copyWith(
                      dragDevices: {
                        PointerDeviceKind.touch,
                        PointerDeviceKind.mouse,
                      },
                    ),
                    child: PageView(
                        controller: _pageController, children: children)))
          ],
        ),
      ),
    );
  }
}
