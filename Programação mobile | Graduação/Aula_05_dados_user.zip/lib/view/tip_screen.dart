import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../model/tip.dart';

class TipScreen extends StatefulWidget {
  const TipScreen({super.key, required this.title});
  final String title;

  @override
  _TipScreenState createState() => _TipScreenState();
}

class _TipScreenState extends State<TipScreen> {
  Tip tip = Tip();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TextFormField(
              initialValue: tip.amount,
              keyboardType: TextInputType.number,
              onChanged: (value) {
                setState(() {
                  tip.amount = value;
                });
              },
              decoration: const InputDecoration(labelText: 'Valor Total'),
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*$'))
              ],
            ),
            InputDecorator(
                decoration:
                    const InputDecoration(labelText: 'Gorjeta  Customizada'),
                child: Slider(
                    min: 1,
                    max: 100,
                    value: double.parse(tip.customTip),
                    onChanged: (value) {
                      setState(() {
                        tip.amount = value.toString();
                      });
                    })),
            Text(tip.defaultTippedAmount),
            Text(tip.customTippedAmount),
            Text(tip.amountPlusDefaultTippedAmount),
            Text(tip.amountPlusCustomTippedAmount),
          ]),
    );
  }
}
