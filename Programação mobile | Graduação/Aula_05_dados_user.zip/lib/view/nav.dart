import 'package:flutter/material.dart';

class TopNavigationBar extends StatefulWidget {
  const TopNavigationBar(
      {super.key,
      required this.title,
      required this.rotulos,
      required this.onTap});
  final String title;
  final List rotulos;
  final Function onTap;

  @override
  _TopNavigationBarState createState() => _TopNavigationBarState();
}

class _TopNavigationBarState extends State<TopNavigationBar> {
  String current = "";

  List<Widget> getChildren() {
    List<Widget> children = [];
    widget.rotulos.asMap().forEach((index, elemento) {
      children.add(TextButton(
        onPressed: () {
          widget.onTap(index, elemento);
        },
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 4.0),
          height: 20,
          decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.blue),
          child: Center(
              child: Text(elemento.toString(),
                  style: TextStyle(color: Colors.white))),
        ),
      ));
    });
    return children;
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        children: [
          Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: getChildren()),
          Text(current),
        ],
      ),
    );
  }
}
