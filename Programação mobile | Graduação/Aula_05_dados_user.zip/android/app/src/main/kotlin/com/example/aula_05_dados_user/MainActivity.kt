package com.example.aula_05_dados_user

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
